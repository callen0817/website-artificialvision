@echo off
setlocal enabledelayedexpansion
title NX Xplode - Uninstaller

echo ======================================================================
echo                  AV TOOLS - NX XPLODE FOR REVIT
echo                           Uninstaller
echo ======================================================================
echo.

set "TARGET_CORE=%APPDATA%\Autodesk\Revit\Addins\AVTools"
set "ADDINS_ROOT=%APPDATA%\Autodesk\Revit\Addins"

echo Removing NX Xplode from installed Revit versions...
for %%Y in (2018 2019 2020 2021 2022 2023 2024 2025 2026 2027 2028) do (
    if exist "!ADDINS_ROOT!\%%Y\AVTools.addin" (
        del /f /q "!ADDINS_ROOT!\%%Y\AVTools.addin" 2>nul
        echo   - Removed from Revit %%Y
    )
)

if exist "!TARGET_CORE!" (
    rd /s /q "!TARGET_CORE!" 2>nul
)

echo.
echo ======================================================================
echo [SUCCESS] NX Xplode has been successfully uninstalled.
echo ======================================================================
echo.
pause
