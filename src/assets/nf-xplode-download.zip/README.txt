================================================================================
                    NX XPLODE FOR AUTODESK REVIT
                 Ribbon: AV Tools  |  Panel: Family
================================================================================
Product:       NX Xplode (Standalone Native Edition)
Version:       1.0.0
Author:        Christopher Allen / Reisource
License:       Free for Commercial and Personal Use (MIT License)
Compatibility: Autodesk Revit 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026, 2027
Prerequisite:  NONE! (pyRevit is NOT required)
================================================================================

--------------------------------------------------------------------------------
1. QUICK START INSTALLATION (1-CLICK)
--------------------------------------------------------------------------------
  1. Extract this entire ZIP archive into a folder on your computer.
  2. Double-click the file named:
         Install NX Xplode.bat
  3. That's it! 
     Launch Revit, and you will see the new [ AV Tools ] tab on your top ribbon 
     with the [ NX Xplode ] button.

--------------------------------------------------------------------------------
2. HOW TO USE NX XPLODE IN REVIT
--------------------------------------------------------------------------------
  STEP 1: Open your parent Revit family (.rfa) in Revit (Family Editor).
  STEP 2: Select the nested family instance in your 3D view or plan view.
          (If there is only 1 nested family instance, you don't even need to 
          select it—NX Xplode will auto-detect it and prompt you to confirm).
  STEP 3: Click the [ AV Tools ] tab on the ribbon.
  STEP 4: Click [ NX Xplode ].
  
  Result:
  • All 3D geometry from the nested family is recreated directly inside the 
    parent family as native, editable 3D solids.
  • Exact location, elevation, 3D rotation, materials, and subcategories are 
    preserved.
  • The original nested family instance is automatically removed.
  • Zero work-plane or hosting errors!

--------------------------------------------------------------------------------
3. UNINSTALLATION
--------------------------------------------------------------------------------
  To uninstall at any time:
    • Double-click "Uninstall NX Xplode.bat".

--------------------------------------------------------------------------------
4. LICENSE
--------------------------------------------------------------------------------
  NX Xplode is 100% free for commercial, personal, and enterprise use under the 
  MIT License. See LICENSE.txt for details.
================================================================================
