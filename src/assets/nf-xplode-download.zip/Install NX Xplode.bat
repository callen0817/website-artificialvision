@echo off
setlocal enabledelayedexpansion
title NX Xplode - 1-Click Installer for Autodesk Revit

echo ======================================================================
echo                  AV TOOLS - NX XPLODE FOR REVIT
echo               1-Click Standalone Native Installer
echo ======================================================================
echo.

set "TARGET_CORE=%APPDATA%\Autodesk\Revit\Addins\AVTools"
set "SRC_DIR=%~dp0Files"

if not exist "!SRC_DIR!\AVTools_NXXplode.dll" (
    echo [ERROR] Could not find installation files!
    echo Please make sure you extract the entire ZIP file before running this installer.
    echo.
    pause
    exit /b 1
)

echo [1/2] Installing core files...
if not exist "!TARGET_CORE!" mkdir "!TARGET_CORE!" 2>nul
copy /Y "!SRC_DIR!\AVTools_NXXplode.dll" "!TARGET_CORE!\AVTools_NXXplode.dll" >nul
copy /Y "!SRC_DIR!\AV NF Xplode.png" "!TARGET_CORE!\AV NF Xplode.png" >nul 2>nul
copy /Y "!SRC_DIR!\icon.png" "!TARGET_CORE!\icon.png" >nul 2>nul

echo [2/2] Registering with your installed Revit versions...
set "ADDINS_ROOT=%APPDATA%\Autodesk\Revit\Addins"

for %%Y in (2018 2019 2020 2021 2022 2023 2024 2025 2026 2027 2028) do (
    if exist "!ADDINS_ROOT!\%%Y" (
        echo   - Registered for Revit %%Y
        (
            echo ^<?xml version="1.0" encoding="utf-8" standalone="no"?^>
            echo ^<RevitAddIns^>
            echo   ^<AddIn Type="Application"^>
            echo     ^<Name^>AV Tools - NX Xplode^</Name^>
            echo     ^<Assembly^>!TARGET_CORE!\AVTools_NXXplode.dll^</Assembly^>
            echo     ^<AddInId^>8B9A6451-39E3-4E8B-A359-838D64A57BC9^</AddInId^>
            echo     ^<FullClassName^>AVTools.App^</FullClassName^>
            echo     ^<VendorId^>AVTL^</VendorId^>
            echo     ^<VendorDescription^>AV Tools, Christopher Allen^</VendorDescription^>
            echo   ^</AddIn^>
            echo ^</RevitAddIns^>
        ) > "!ADDINS_ROOT!\%%Y\AVTools.addin"
    )
)

echo.
echo ======================================================================
echo [SUCCESS] NX Xplode is installed and ready to use!
echo ======================================================================
echo.
echo Next Steps:
echo   1. Start Autodesk Revit.
echo   2. Look on the top ribbon for the new [ AV Tools ] tab.
echo   3. Open any Revit Family (.rfa) and click [ NX Xplode ].
echo.
pause
